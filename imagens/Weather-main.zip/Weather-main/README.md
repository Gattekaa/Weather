# Projeto que mostrará o clima utilizando API pública.
Tecnologias utilizadas até o momento: HTML e CSS

### Preview
<img align="center" alt="html5" src="https://cdn.discordapp.com/attachments/773787772167127071/904137133458063390/unknown.png"/>
